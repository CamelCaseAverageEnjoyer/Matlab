function kron = kronoker(a,b)
if abs(a - b)<1e-6
    kron = 1;
else
    kron = 0;
end