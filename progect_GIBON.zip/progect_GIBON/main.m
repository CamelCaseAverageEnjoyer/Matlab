function main()
%% Initialization X - construction info
N = 11; % Кол-во палок
N_nodes = 7; % Кол-во узлов
r = zeros(N_nodes,3); % Координата каждой палки
r(1,1) = 0; r(1,2) = 0; r(1,3) = 0; % Расположение палок
r(2,1) = 3; r(2,2) = 0; r(2,3) = 5;
r(3,1) = 3; r(3,2) = 0; r(3,3) = -3;
r(4,1) = 6; r(4,2) = 0; r(4,3) = 2;
r(5,1) = 6; r(5,2) = 0; r(5,3) = -5;
r(6,1) = 11; r(6,2) = 0; r(6,3) = 5;
r(7,1) = 18; r(7,2) = 0; r(7,3) = 0;
m_initial = 6;
% X =  id | mass | length | id_node_1 | id_node_2 | x1 | y1 | z1 | x2 | y2 | z2 | flag_1 | flag_2
% флаг1/2 - закреплён ли узел у палки
X = [1,m_initial, 0,   1, 2,     r(1,1),r(1,2),r(1,3),    r(2,1),r(2,2),r(2,3),     1, 1;
    2, m_initial, 0,   1, 3,     r(1,1),r(1,2),r(1,3),    r(3,1),r(3,2),r(3,3),     1, 1;
    3, m_initial, 0,   2, 3,     r(2,1),r(2,2),r(2,3),    r(3,1),r(3,2),r(3,3),     0, 0;
    4, m_initial, 0,   2, 4,     r(2,1),r(2,2),r(2,3),    r(4,1),r(4,2),r(4,3),     0, 0;
    5, m_initial, 0,   3, 4,     r(3,1),r(3,2),r(3,3),    r(4,1),r(4,2),r(4,3),     0, 0;
    6, m_initial, 0,   3, 5,     r(3,1),r(3,2),r(3,3),    r(5,1),r(5,2),r(5,3),     0, 0;
    7, m_initial, 0,   4, 5,     r(4,1),r(4,2),r(4,3),    r(5,1),r(5,2),r(5,3),     0, 0;
    8, m_initial, 0,   4, 6,     r(4,1),r(4,2),r(4,3),    r(6,1),r(6,2),r(6,3),     0, 0;
    9, m_initial, 0,   5, 6,     r(5,1),r(5,2),r(5,3),    r(6,1),r(6,2),r(6,3),     0, 0;
    10,m_initial, 0,   5, 7,     r(5,1),r(5,2),r(5,3),    r(7,1),r(7,2),r(7,3),     0, 0;
    11,m_initial, 0,   6, 7,     r(6,1),r(6,2),r(6,3),    r(7,1),r(7,2),r(7,3),     0, 0];

hold on;
for i = 1 : N % Каждую палку рисуем
    % Просто тут удобно считать длинну, кстати хер знает зачем она нужна :)
    X(i,3) = sqrt((r(X(i,4),1)-r(X(i,5),1))^2 + (r(X(i,4),2)-r(X(i,5),2))^2 + (r(X(i,4),3)-r(X(i,5),3))^2);
    % Ready construction, Oxz
    plot([r(X(i,4),1),r(X(i,5),1)], [r(X(i,4),3),r(X(i,5),3)], 'c');
end
hold off;

%% Begin parameters  - НУ
N_calc = 100;
dt = 0.1;
m_apparatus = 2;
M_total = 11*6;
G_grav = 6.67408e-11;
M_earth = 5.9742e24;
R_orbit = 6800e3;
mu = G_grav*M_earth;
w_hkw = sqrt(mu/R_orbit^3);
w_hkw_vec = [0;0;w_hkw];
w__1 = [0;0;0];

% КВАТЕРНИОНЫ 
L_A_tmp = zeros(N_calc + 1,4);
L_U_tmp = zeros(N_calc + 1,4);
tmp1 = [1/sqrt(2),0,1/sqrt(2),0];
tmp2 = [1/sqrt(2),0,0,1/sqrt(2)];
kj = quatmultiply(tmp1,tmp2)
L_A_tmp(1,:) = kj;
L_U_tmp(1,:) = kj;
L_A = L_A_tmp; 
L_U = L_U_tmp;

A = quat2dcm(L_A(1,:));

r = [0,0,0];
r_center = call_center_mass(X);
R = [0,0,0];

%% Show the result of past iterations
hold on;
for ii = 1 : N
    % Ready construction, Oxz
    if (X(ii,12) + X(ii,13))> 0 % Если закреплено чета
        x_1 = X(ii,6);
        y_1 = X(ii,7);
        z_1 = X(ii,8);
        x_2 = X(ii,9);
        y_2 = X(ii,10);
        z_2 = X(ii,11);
    else % Ааааа вот зачем длина нужна
        x_1 = 0; % Ему порисовать захотелось
        y_1 = 0;
        z_1 = 0;
        x_2 = -X(ii,3);
        y_2 = 0;
        z_2 = 0;
    end
    plot([x_1,x_2], [z_1,z_2], 'm');
end
hold off;

%% Possible transoprt
j_todo = 1; % Берём первую попавшуюся палку
X_possible = call_possible_transport(X,N_nodes,N) % А че а куда можно то
X_without = X;
X_without(find(X_without(:,1) == X_possible(1,1)),:)=[]; 

tmp = r_center;
r_center = call_center_mass(X_without);
R = R - r_center + tmp;
J = call_inertion(X_without);
J_1 = inv(J); % Обратная матричкаfor k = 1 : N_m

ddv = 0.1;
for i_v_x = 1 : 4  % НАЧИНАЕМ ПУЛЯТЬ 
    for i_v_y = 0 : 0
        for i_v_z = 1 : 4
            % Задаток для анимы
            plot([1,2],[1,2]);
            ax = gca;
            M = getframe;
            cla;
            
            m_app_j = m_apparatus + X_possible(j_todo, 2);% X_possible(j_todo, 2) - масса стержня
            dv = [i_v_x*ddv;i_v_y*ddv;i_v_z*ddv];
            w = w__1 - m_app_j*J_1*cross(r',dv);  
            r0 = R - r_center; % Только для прыжка туда
            R0 = R;
            dV = -(m_app_j)/(M_total - X_possible(j_todo, 2))*dv;
            C_r =  [2*r0(3) + dv(1)/w_hkw, dv(3)/w_hkw, -3*r0(3) - 2*dv(1)/w_hkw, r0(1) - 2*dv(3)/w_hkw, dv(2)/w_hkw, r0(2)];
            C_R =  [2*R0(3) + dV(1)/w_hkw, dV(3)/w_hkw, -3*R0(3) - 2*dV(1)/w_hkw, R0(1) - 2*dV(3)/w_hkw, dV(2)/w_hkw, R0(2)];
            flag = 0;
            % Ин Тег Рируем
            for i = 1 : N_calc
                t_i = i*dt;
                % Поступательное движение
                r_i = r_HKW(C_r,mu,w_hkw,t_i);
                R_i = r_HKW(C_R,mu,w_hkw,t_i);
                
                % Вращательное движение
                L_U(i+1,:) = L_U(i,:) + dt/2*quatmultiply(L_U(i,:), [0,w_hkw_vec(1),w_hkw_vec(2),w_hkw_vec(3)]);
                U = quat2dcm(L_U(i+1,:));
                direction = inv(U)*[0;0;1];
                A_1 = inv(A);
                w = w + J_1*(3*A*(mu/R_orbit^3*cross(direction, A*J*A_1*direction)) - cross(w,J*w))*dt;
                L_A(i+1,:) = L_A(i,:) + dt/2*quatmultiply(L_A(i,:), [0,w(1),w(2),w(3)]);
                A = quat2dcm(L_A(i+1,:));
                S = A*inv(U);
                S_1 = inv(S);
                
                %%%%%%%%%%%%%%%%%%%%
                
                hold on;
                for ii = 1 : N
                    x_1 = X(ii,6);
                    y_1 = X(ii,7);
                    z_1 = X(ii,8);
                    x_2 = X(ii,9);
                    y_2 = X(ii,10);
                    z_2 = X(ii,11);
                    r_tmp_1 = S_1*[x_1;0;z_1] + R_i;
                    r_tmp_2 = S_1*[x_2;0;z_2] + R_i;
                    plot([r_tmp_1(1), r_tmp_2(1)], [r_tmp_1(3), r_tmp_2(3)], 'c');
                    ax = gca;
                end
                for ii = 1 : N
                    % Ready construction, Oxz
                    if (X(ii,12) + X(ii,13))> 0 % Если закреплено чета
                        x_1 = X(ii,6);
                        y_1 = X(ii,7);
                        z_1 = X(ii,8);
                        x_2 = X(ii,9);
                        y_2 = X(ii,10);
                        z_2 = X(ii,11);
                    else 
                        x_1 = 0; 
                        y_1 = 0;
                        z_1 = 0;
                        x_2 = -X(ii,3);
                        y_2 = 0;
                        z_2 = 0;    
                    end
                    r_tmp_1 = S_1*[x_1;0;z_1] + R_i;
                    r_tmp_2 = S_1*[x_2;0;z_2] + R_i;
                    plot([r_tmp_1(1), r_tmp_2(1)], [r_tmp_1(3), r_tmp_2(3)], 'm');
                    ax = gca;
                end
                scatter(r_i(1), r_i(3));
                ax.XAxisLocation = 'origin';
                ax.YAxisLocation = 'origin';
                ax = gca;
                hold off;
                M(i+1) = getframe;
                cla;
                
                
                
                
                %%%%%%%%%%%%%%%%%
                
                
                % Попало?
                % ПРОПУСКАЮ IF ЧТОБЫ ПОСМОТРЕТЬ ЧТО ПРОИСХОДИТ
                flag = 1;  % ---> break
            end
            movie(M);
            
            if flag > 0
                r_dot = r_dot_HKW(C_r,mu,w_hkw,t_i);
                R_dot = r_dot_HKW(C_R,mu,w_hkw,t_i);
                v_tmp = r_dot - R_dot;
                r_tmp = r - R + r_center;
                J_tmp = J;
                for i_J = 1 : 3
                    for j_J = 1 : 3
                        J_tmp(i_J,j_J) = J_tmp(i_J,j_J) + m_app_j*(kronoker(i_J,j_J)*sqrt(r_tmp(1)^2+r_tmp(2)^2+r_tmp(3)^2) - r_tmp(i_J)*r_tmp(j_J));
                    end
                end
                w__1_tmp = inv(J_tmp)*(cross(r_tmp,v_tmp)'*m_app_j + J*w);
                
                
                % Запишем в файл
                %{
                fid = fopen("file_jump.dat",'a');
                if fid == -1
                    error("File is not opened");
                end
                fwrite(fid, i, 'int');
                for iii = 1 : 6 
                    fwrite(fid, C_r(iii), 'double');
                    fwrite(fid, C_R(iii), 'double');
                end
                fwrite(fid, w__1_tmp, 'double');
                for iii = 1 : i
                    for iiii = 1:4
                        fwrite(fid, L_A(iii+1,iiii), 'double');
                        fwrite(fid, L_U(iii+1,iiii), 'double');
                    end
                end
                fclose(fid);
                %}
                
                
                %Ой, вроде всё
            end
        end
    end 
end

%% Display   -- ВЫВОД ТРАЕКТОРИИ

i_record = 0;
fid = fopen('file_jump.dat',r);
if fid == -1
    error('File is not opened');
end

% ПОКА ЧТО ДЕЛАЮ РУЧКАМИ
%while feof(fid) % (end где-то будет далеко)

i = fread(fid);
C_r = zeros(6);
C_R = zeros(6);
L_A_tmp = zeros(N_calc,4);
L_U_tmp = zeros(N_calc,4);
L_A = L_A_tmp; 
L_U = L_U_tmp;

for i = 1 to 6 do
    C_r(i) = fread(fid);
    C_R(i) = fread(fid);
end

w__1_tmp = fread(fid);

for i = 1 to i do
    for iiii = 1:4
        L_A(i,iiii) = fread(fid);
        L_U(i,iiii) = fread(fid);
    end
end

% Задаток для анимации
plot([1, 2], [1, 2], m);
f = getframe;
M(1) = f;
[im,map] = rgb2ind(f.cdata,256);
im(1,1,1,10) = 0;
for ii = 1 : i
    r_ii = r_HKW(C_r,mu,w_hkw,ii*dt);
    R_ii = r_HKW(C_R,mu,w_hkw,ii*dt);
    A = quart2dcm(L_A(ii));
    U = quart2dcm(L_U(ii));
    S = A*inv(U);
    S_1 = inv(S);
    hold on;
    for ii = 1 : N
        x_1 = X(ii,6);
        y_1 = X(ii,7);
        z_1 = X(ii,8);
        x_2 = X(ii,9);
        y_2 = X(ii,10);
        z_2 = X(ii,11);
        r_tmp_1 = S_1*[x_1;0;z_1] + R_ii;
        r_tmp_2 = S_1*[x_2;0;z_2] + R_ii;
        plot([r_tmp_1(1), r_tmp_2(1)], [r_tmp_1(3), r_tmp_2(3)], 'c');
    end
    for ii = 1 : N
        % Ready construction, Oxz
        if (X(ii,12) + X(ii,13))> 0 % Если закреплено чета
            x_1 = X(ii,6);
            y_1 = X(ii,7);
            z_1 = X(ii,8);
            x_2 = X(ii,9);
            y_2 = X(ii,10);
            z_2 = X(ii,11);
        else 
            x_1 = 0; 
            y_1 = 0;
            z_1 = 0;
            x_2 = -X(ii,3);
            y_2 = 0;
            z_2 = 0;    
        end
        r_tmp_1 = S_1*[x_1;0;z_1] + R_ii;
        r_tmp_2 = S_1*[x_2;0;z_2] + R_ii;
        plot([r_tmp_1(1), r_tmp_2(1)], [r_tmp_1(3), r_tmp_2(3)], 'm');
    end
    scatter(r_ii(1), r_ii(3));
    hold off;
    f = getframe;
    M(ii+1) = f;
    im(:,:,1,k) = rgb2ind(f.cdata,map);
end
% movie(M);

DelTime = 0;
i_record = i_record + 1;
name = 'jump _ ' + string(i_record) + '.gif';
imwrite(im,map,name,'DelayTime',DelTime,'LoopCount',inf)
save('Results.mat')

%end %ОТНОСИТСЯ К WHILE

