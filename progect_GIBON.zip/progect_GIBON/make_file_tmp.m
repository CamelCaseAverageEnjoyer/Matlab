function make_file_tmp()
