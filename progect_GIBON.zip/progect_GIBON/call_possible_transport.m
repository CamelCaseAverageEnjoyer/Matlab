function X_possible = call_possible_transport(X, N_nodes, N)
tmp_N = 0; 
tmp_X_possible = zeros(N,9);
% Ид / масса / ид1стороны / ид2стороны / х / у / z / можна 1? / можна 2?

mask_half_fixed = zeros(1,N);
mask_full_fixed = zeros(1,N);
mask_non_fixed = zeros(1,N);
for i = 1:N
    if (X(i,12) + X(i,13)) == 2
        mask_full_fixed(i) = mask_full_fixed(i) + 1;
    end
    if (X(i,12) + X(i,13)) == 1
        mask_half_fixed(i) = mask_half_fixed(i) + 1;
    end
    if (X(i,12) + X(i,13)) == 0
        mask_non_fixed(i) = mask_non_fixed(i) + 1;
    end
end


needed_number_nodes = zeros(1,N_nodes);
current_number_nodes = zeros(1,N_nodes);
mask_open_nodes = zeros(1,N_nodes);
needed_number_nodes(1) = 1; % Костыль на начальную точечку
current_number_nodes(1) = 1;
for i = 1:N
    needed_number_nodes(X(i,4)) = needed_number_nodes(X(i,4)) + 1; % А че а сколько надо на узел
    needed_number_nodes(X(i,5)) = needed_number_nodes(X(i,5)) + 1; 
    current_number_nodes(X(i,4)) = current_number_nodes(X(i,4)) + X(i,12);
    current_number_nodes(X(i,5)) = current_number_nodes(X(i,5)) + X(i,13);
end

for i = 1:N_nodes % А куда можно лепить
    if (needed_number_nodes(i) - current_number_nodes(i) > 0) & (current_number_nodes(i) > 0) 
        mask_open_nodes(i) = 1;
    end
end
% Ид / масса / ид1стороны / ид2стороны / х / у / з захуяривания / можна 1? / можна 2?
if sum(mask_non_fixed) > 0 % нужный костыль
    for i = 1:N
        if mask_non_fixed(i) > 0 % берём нетронутые со склада
            if mask_open_nodes(X(i,4)) + mask_open_nodes(X(i,5)) > 0 % проверка надобности балки
                % ОСНОВНОЙ КОД
                tmp_N = tmp_N + 1;
                tmp_X_possible(tmp_N, 1) = X(i,1);
                tmp_X_possible(tmp_N, 2) = X(i,2);
                tmp_X_possible(tmp_N, 3) = X(i,4);
                tmp_X_possible(tmp_N, 4) = X(i,5);
                
                tmp_X_possible(tmp_N, 5) = X(i,6)*mask_open_nodes(X(i,4)) + X(i,9)*(1-mask_open_nodes(X(i,4)));
                tmp_X_possible(tmp_N, 6) = X(i,7)*mask_open_nodes(X(i,4)) + X(i,10)*(1-mask_open_nodes(X(i,4)));
                tmp_X_possible(tmp_N, 7) = X(i,8)*mask_open_nodes(X(i,4)) + X(i,11)*(1-mask_open_nodes(X(i,4)));
                
                tmp_X_possible(tmp_N, 8) = mask_open_nodes(X(i,4));
                tmp_X_possible(tmp_N, 9) = mask_open_nodes(X(i,5));
            end
        end
    end
end


X_possible = tmp_X_possible(1:tmp_N,:);