function A1 = call_rotation(R,J,t,r,v,A)
N = 100;
dt = t/N;
for i = 1:N
    
    
    
    
end