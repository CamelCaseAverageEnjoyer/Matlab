function L = q_dot(q1,q2)
r1 = q1(1);
v1 = [q1(2), q1(3), q1(4)];
r2 = q2(1);
v2 = [q2(2), q2(3), q2(4)];
r = r1*r2 - dot(v1,v2);
v = r1*v2 + r2*v1 + cross(v1,v2);
L = quaternion(r,v(1),v(2),v(3));
% Бля а как дальше )))))
