function r = r_HKW(C,mu,w,t)

r = [0,0,0];
r(1) = -3*C(1)*w*t + 2*C(2)*cos(w*t) - 2*C(3)*sin(w*t) + C(4);
r(2) = C(6)*cos(w*t) + C(5)*sin(w*t);
r(3) = 2*C(1) + C(3)*cos(w*t) + C(2)*sin(w*t);