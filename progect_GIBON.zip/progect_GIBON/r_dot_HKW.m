function r = r_dot_HKW(C,mu,w,t)

r = [0,0,0];
r(1) = -3*C(1)*w - 2*w*C(2)*sin(w*t) - 2*w*C(3)*cos(w*t);
r(2) = w*C(5)*cos(w*t) -w*C(6)*sin(w*t);
r(3) = -w*C(3)*sin(w*t) + w*C(2)*cos(w*t);